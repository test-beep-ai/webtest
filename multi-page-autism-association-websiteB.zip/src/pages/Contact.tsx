import { useState, FormEvent } from "react";

export default function Contact() {
  const [formData, setFormData] = useState({
    parentName: "",
    phone: "",
    email: "",
    childName: "",
    childAge: "",
    service: "",
    message: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const services = [
    "التخاطب",
    "أخصائي أرثوفوني",
    "تعديل السلوك",
    "العلاج الشغلي",
    "الدعم النفسي",
    "تكامل حسي",
    "استشارة عامة",
  ];

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    
    // Clear error when user types
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.parentName.trim()) {
      newErrors.parentName = "اسم ولي الأمر مطلوب";
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = "رقم الهاتف مطلوب";
    } else if (!/^[0-9\s+()-]{10,}$/.test(formData.phone)) {
      newErrors.phone = "يرجى إدخال رقم هاتف صالح";
    }
    
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "يرجى إدخال بريد إلكتروني صالح";
    }
    
    if (!formData.childName.trim()) {
      newErrors.childName = "اسم الطفل مطلوب";
    }
    
    if (!formData.childAge) {
      newErrors.childAge = "عمر الطفل مطلوب";
    } else if (parseInt(formData.childAge) < 2 || parseInt(formData.childAge) > 18) {
      newErrors.childAge = "يجب أن يكون عمر الطفل بين 2 و 18 سنة";
    }
    
    if (!formData.service) {
      newErrors.service = "يرجى اختيار الخدمة";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitSuccess(true);
      setFormData({
        parentName: "",
        phone: "",
        email: "",
        childName: "",
        childAge: "",
        service: "",
        message: "",
      });
    }, 2000);
  };

  if (submitSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 flex items-center justify-center">
        <div className="max-w-md mx-auto text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fas fa-check-circle text-green-500 text-4xl"></i>
          </div>
          <h2 className="text-3xl font-bold text-primary mb-4">
            شكرًا لك!
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            تم استلام طلبك بنجاح. سنتواصل معك في أقرب وقت ممكن لحجز
            الموعد.
          </p>
          <div className="space-y-4">
            <a href="/" className="btn-primary block">
              العودة إلى الصفحة الرئيسية
            </a>
            <a href="/contact" className="btn-secondary block">
              إرسال طلب آخر
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl lg:text-4xl font-bold text-primary mb-4">
            التواصل وحجز المواعيد
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            تواصل معنا لحجز مواعيد الجلسات العلاجية أو للحصول على
            معلومات إضافية
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Contact Form */}
          <div className="bg-white p-8 rounded-xl shadow-md">
            <h2 className="text-2xl font-bold text-primary mb-6">
              استمارة حجز المواعيد
            </h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Parent Information */}
              <div className="bg-light p-4 rounded-lg">
                <h3 className="text-lg font-bold text-primary mb-4">
                  معلومات ولي الأمر
                </h3>
                <div className="space-y-4">
                  <div>
                    <label
                      htmlFor="parentName"
                      className="block text-sm font-medium text-gray-700 mb-2"
                    >
                      الاسم الكامل *
                    </label>
                    <input
                      type="text"
                      id="parentName"
                      name="parentName"
                      value={formData.parentName}
                      onChange={handleChange}
                      className={`input-field ${
                        errors.parentName ? "border-red-500" : ""
                      }`}
                      placeholder="ادخل اسمك الكامل"
                    />
                    {errors.parentName && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.parentName}
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="phone"
                      className="block text-sm font-medium text-gray-700 mb-2"
                    >
                      رقم الهاتف *
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className={`input-field ${
                        errors.phone ? "border-red-500" : ""
                      }`}
                      placeholder="ادخل رقم هاتفك"
                    />
                    {errors.phone && (
                      <p className="text-red-500 text-sm mt-1">{errors.phone}</p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="email"
                      className="block text-sm font-medium text-gray-700 mb-2"
                    >
                      البريد الإلكتروني (اختياري)
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className={`input-field ${
                        errors.email ? "border-red-500" : ""
                      }`}
                      placeholder="ادخل بريدك الإلكتروني"
                    />
                    {errors.email && (
                      <p className="text-red-500 text-sm mt-1">{errors.email}</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Child Information */}
              <div className="bg-light p-4 rounded-lg">
                <h3 className="text-lg font-bold text-primary mb-4">
                  معلومات الطفل
                </h3>
                <div className="space-y-4">
                  <div>
                    <label
                      htmlFor="childName"
                      className="block text-sm font-medium text-gray-700 mb-2"
                    >
                      اسم الطفل *
                    </label>
                    <input
                      type="text"
                      id="childName"
                      name="childName"
                      value={formData.childName}
                      onChange={handleChange}
                      className={`input-field ${
                        errors.childName ? "border-red-500" : ""
                      }`}
                      placeholder="ادخل اسم الطفل"
                    />
                    {errors.childName && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.childName}
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="childAge"
                      className="block text-sm font-medium text-gray-700 mb-2"
                    >
                      عمر الطفل (بالسنوات) *
                    </label>
                    <input
                      type="number"
                      id="childAge"
                      name="childAge"
                      value={formData.childAge}
                      onChange={handleChange}
                      min="2"
                      max="18"
                      className={`input-field ${
                        errors.childAge ? "border-red-500" : ""
                      }`}
                      placeholder="ادخل عمر الطفل"
                    />
                    {errors.childAge && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.childAge}
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="service"
                      className="block text-sm font-medium text-gray-700 mb-2"
                    >
                      الخدمة المطلوبة *
                    </label>
                    <select
                      id="service"
                      name="service"
                      value={formData.service}
                      onChange={handleChange}
                      className={`input-field ${
                        errors.service ? "border-red-500" : ""
                      }`}
                    >
                      <option value="">اختر الخدمة</option>
                      {services.map((service) => (
                        <option key={service} value={service}>
                          {service}
                        </option>
                      ))}
                    </select>
                    {errors.service && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.service}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {/* Additional Information */}
              <div>
                <label
                  htmlFor="message"
                  className="block text-sm font-medium text-gray-700 mb-2"
                >
                  ملاحظات إضافية (اختياري)
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  className="input-field resize-none"
                  placeholder="ادخل أي ملاحظات أو أسئلة إضافية"
                ></textarea>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-primary w-full py-4 text-lg"
              >
                {isSubmitting ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2"></i>
                    جاري الإرسال...
                  </>
                ) : (
                  "إرسال الطلب"
                )}
              </button>
            </form>
          </div>

          {/* Contact Information */}
          <div className="space-y-6">
            {/* Association Info */}
            <div className="bg-white p-8 rounded-xl shadow-md">
              <h2 className="text-2xl font-bold text-primary mb-6">
                معلومات الاتصال
              </h2>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <i className="fas fa-map-marker-alt text-primary text-xl mt-1"></i>
                  <div>
                    <h3 className="font-bold text-primary">العنوان:</h3>
                    <p className="text-gray-600">
                      حي العربي بن مهيدي، ص.ب 84
                      <br />
                      الحناية، تلمسان، الجزائر
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <i className="fas fa-envelope text-primary text-xl mt-1"></i>
                  <div>
                    <h3 className="font-bold text-primary">البريد الإلكتروني:</h3>
                    <p className="text-gray-600">
                      autisme.hennaya@hotmail.com
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <i className="fas fa-phone text-primary text-xl mt-1"></i>
                  <div>
                    <h3 className="font-bold text-primary">الهاتف:</h3>
                    <p className="text-gray-600">
                      بلدية الحنايا - ولاية تلمسان
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Opening Hours */}
            <div className="bg-white p-8 rounded-xl shadow-md">
              <h2 className="text-2xl font-bold text-primary mb-6">
                أوقات العمل
              </h2>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="font-medium text-gray-700">الأحد - الخميس</span>
                  <span className="text-primary font-medium">08:00 - 17:00</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-gray-700">الجمعة</span>
                  <span className="text-primary font-medium">08:00 - 13:00</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-gray-700">السبت</span>
                  <span className="text-gray-500 font-medium">مغلق</span>
                </div>
              </div>
              <p className="text-gray-500 text-sm mt-4">
                * الجلسات تتطلب حجزًا مسبقًا
              </p>
            </div>

            {/* Facebook Page */}
            <div className="bg-white p-8 rounded-xl shadow-md">
              <h2 className="text-2xl font-bold text-primary mb-6">
                تابعونا على الفيسبوك
              </h2>
              <a
                href="https://www.facebook.com/profile.php?id=61590665260682"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center w-full bg-blue-600 hover:bg-blue-700 text-white py-4 px-6 rounded-lg transition-colors"
              >
                <i className="fab fa-facebook text-3xl mr-4"></i>
                <div>
                  <p className="font-bold">صفحتنا الرسمية على الفيسبوك</p>
                  <p className="text-sm opacity-90">
                    جمعية الأمل لأطفال طيف التوحد
                  </p>
                </div>
              </a>
            </div>

            {/* Map Placeholder */}
            <div className="bg-white p-8 rounded-xl shadow-md">
              <h2 className="text-2xl font-bold text-primary mb-6">
                موقعنا على الخريطة
              </h2>
              <div className="bg-gray-100 h-64 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <i className="fas fa-map-marker-alt text-primary text-6xl mb-4"></i>
                  <p className="text-gray-600">
                    خريطة توضيحية لمقر الجمعية
                  </p>
                  <p className="text-sm text-gray-500 mt-2">
                    (يمكنك استخدام Google Maps للبحث عن: جمعية الأمل لأطفال
                    طيف التوحد، الحنايا، تلمسان)
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <section className="mt-12 bg-white p-8 rounded-xl shadow-md">
          <h2 className="text-2xl font-bold text-primary mb-6">
            الأسئلة الشائعة
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-bold text-primary mb-2">
                كيف يمكنني حجز موعد؟
              </h3>
              <p className="text-gray-600 text-sm">
                يمكنك حجز موعد عن طريق ملء استمارة الحجز أعلاه أو الاتصال
                بنا مباشرة عبر الهاتف أو زيارة مقر الجمعية.
              </p>
            </div>
            <div>
              <h3 className="font-bold text-primary mb-2">
                ما هي تكلفة الجلسات؟
              </h3>
              <p className="text-gray-600 text-sm">
                نقدم باقات علاجية مختلفة الأسعار. يمكنك الاطلاع على أسعار
                الباقات في صفحة الخدمات أو الاتصال بنا للحصول على عرض
                سعر مخصص.
              </p>
            </div>
            <div>
              <h3 className="font-bold text-primary mb-2">
                هل تقبلون التأمين الصحي؟
              </h3>
              <p className="text-gray-600 text-sm">
                حاليًا، لا نقبل التأمين الصحي. لكننا نعمل على توفير خدمات
                ذات جودة عالية بأسعار معقولة.
              </p>
            </div>
            <div>
              <h3 className="font-bold text-primary mb-2">
                ما هو عمر الأطفال الذين تستقبلونهم؟
              </h3>
              <p className="text-gray-600 text-sm">
                نستقبل الأطفال من عمر 2 سنة حتى 18 سنة. نقدم برامج مخصصة
                لكل فئة عمرية.
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
