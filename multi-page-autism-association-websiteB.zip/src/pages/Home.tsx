import { Link } from "react-router-dom";

export default function Home() {
  return (
    <div className="bg-gray-50">
      {/* Hero Section */}
      <section className="hero-gradient text-white py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl lg:text-5xl font-bold leading-tight">
                جمعية الأمل لأطفال طيف التوحد
                <span className="block text-2xl lg:text-3xl font-normal opacity-90">
                  (بلدية الحنايا)
                </span>
              </h1>
              <p className="text-xl opacity-90">
                معًا نبني مستقبلًا مشرقًا لأطفالنا ذوي الاحتياجات الخاصة
              </p>
              <div className="flex flex-wrap gap-4">
                <Link
                  to="/contact"
                  className="btn-secondary"
                >
                  حجز موعد
                </Link>
                <a
                  href="https://www.facebook.com/profile.php?id=61590665260682"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-accent"
                >
                  <i className="fab fa-facebook mr-2"></i>
                  زيارتنا على الفيسبوك
                </a>
              </div>
            </div>
            <div className="flex justify-center">
              <div className="relative">
                <div className="w-80 h-80 bg-white bg-opacity-20 rounded-full flex items-center justify-center">
                  <i className="fas fa-child text-8xl text-white opacity-80"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-primary mb-4">
              من نحن؟
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              جمعية الأمل لأطفال طيف التوحد هي جمعية خيرية غير ربحية تأسست لخدمة
              أطفال طيف التوحد وأسرهم في منطقة الحناية، تلمسان.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="service-card bg-light p-6 rounded-xl">
              <div className="w-16 h-16 bg-primary bg-opacity-20 rounded-full flex items-center justify-center mb-4">
                <i className="fas fa-bullseye text-primary text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-primary mb-3">رسالتنا</h3>
              <p className="text-gray-600">
                توفير الدعم الشامل لأطفال التوحد من خلال برامج علاجية وتعليمية
                متخصصة لتحسين جودة حياتهم.
              </p>
            </div>

            <div className="service-card bg-light p-6 rounded-xl">
              <div className="w-16 h-16 bg-secondary bg-opacity-20 rounded-full flex items-center justify-center mb-4">
                <i className="fas fa-eye text-secondary text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-primary mb-3">رؤيتنا</h3>
              <p className="text-gray-600">
                مجتمع شامل يدعم أطفال التوحد ويوفر لهم الفرص اللازمة للنمو
                والتطور في بيئة آمنة ومحفزة.
              </p>
            </div>

            <div className="service-card bg-light p-6 rounded-xl">
              <div className="w-16 h-16 bg-accent bg-opacity-20 rounded-full flex items-center justify-center mb-4">
                <i className="fas fa-heart text-accent text-2xl"></i>
              </div>
              <h3 className="text-xl font-bold text-primary mb-3">قيمنا</h3>
              <p className="text-gray-600">
                الاحترام، التعاطف، الالتزام، والتميز في تقديم خدماتنا لأطفال
                التوحد وأسرهم.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-primary mb-4">
              خدماتنا
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              نقدم مجموعة واسعة من الخدمات العلاجية والتأهيلية لأطفال طيف
              التوحد
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <div className="bg-white p-6 rounded-xl shadow-md card-hover">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 bg-primary bg-opacity-20 rounded-full flex items-center justify-center">
                  <i className="fas fa-microphone text-primary text-xl"></i>
                </div>
                <h3 className="text-xl font-bold text-primary">التخاطب</h3>
              </div>
              <p className="text-gray-600 mb-4">
                برامج متخصصة لتطوير مهارات التواصل اللفظي وغير اللفظي
              </p>
              <Link to="/services" className="text-primary font-medium hover:underline">
                معرفة المزيد
              </Link>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md card-hover">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 bg-secondary bg-opacity-20 rounded-full flex items-center justify-center">
                  <i className="fas fa-brain text-secondary text-xl"></i>
                </div>
                <h3 className="text-xl font-bold text-primary">تعديل السلوك</h3>
              </div>
              <p className="text-gray-600 mb-4">
                استراتيجيات فعالة لتعديل السلوكيات السلبية وتعزيز السلوكيات
                الإيجابية
              </p>
              <Link to="/services" className="text-primary font-medium hover:underline">
                معرفة المزيد
              </Link>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md card-hover">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 bg-accent bg-opacity-20 rounded-full flex items-center justify-center">
                  <i className="fas fa-hands text-accent text-xl"></i>
                </div>
                <h3 className="text-xl font-bold text-primary">العلاج الشغلي</h3>
              </div>
              <p className="text-gray-600 mb-4">
                أنشطة علاجية لتطوير المهارات الحركية الدقيقة والجمالية
              </p>
              <Link to="/services" className="text-primary font-medium hover:underline">
                معرفة المزيد
              </Link>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md card-hover">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-12 h-12 bg-primary bg-opacity-20 rounded-full flex items-center justify-center">
                  <i className="fas fa-user-md text-primary text-xl"></i>
                </div>
                <h3 className="text-xl font-bold text-primary">الدعم النفسي</h3>
              </div>
              <p className="text-gray-600 mb-4">
                جلسات دعم نفسية لأسر الأطفال ذوي التوحد
              </p>
              <Link to="/services" className="text-primary font-medium hover:underline">
                معرفة المزيد
              </Link>
            </div>
          </div>

          <div className="text-center">
            <Link to="/services" className="btn-primary">
              عرض كافة الخدمات
            </Link>
          </div>
        </div>
      </section>

      {/* Location Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-primary mb-4">
              مقرنا
            </h2>
            <p className="text-lg text-gray-600">
              زورونا في مقر جمعية الأمل بأطفال طيف التوحد
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-light p-8 rounded-xl">
              <h3 className="text-2xl font-bold text-primary mb-6">
                معلومات الاتصال
              </h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <i className="fas fa-map-marker-alt text-primary text-xl mt-1"></i>
                  <div>
                    <h4 className="font-bold text-primary">العنوان:</h4>
                    <p className="text-gray-600">
                      حي العربي بن مهيدي، ص.ب 84، الحنايا، تلمسان، الجزائر
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <i className="fas fa-envelope text-primary text-xl mt-1"></i>
                  <div>
                    <h4 className="font-bold text-primary">البريد الإلكتروني:</h4>
                    <p className="text-gray-600">
                      autisme.hennaya@hotmail.com
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <i className="fas fa-phone text-primary text-xl mt-1"></i>
                  <div>
                    <h4 className="font-bold text-primary">الهاتف:</h4>
                    <p className="text-gray-600">
                      بلدية الحنايا - ولاية تلمسان
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gray-100 p-8 rounded-xl flex items-center justify-center">
              <div className="text-center">
                <i className="fas fa-map text-primary text-6xl mb-4"></i>
                <p className="text-gray-600">
                  خريطة توضيحية لمقر الجمعية
                </p>
                <p className="text-sm text-gray-500 mt-2">
                  (يمكنك استخدام Google Maps للبحث عن: جمعية الأمل لأطفال طيف
                  التوحد، الحنايا، تلمسان)
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            انضم إلينا اليوم
          </h2>
          <p className="text-xl text-white opacity-90 mb-8 max-w-2xl mx-auto">
            حدد موعدًا الآن لبدء رحلة الدعم والتطوير لطفلك
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link to="/contact" className="btn-secondary">
              حجز موعد
            </Link>
            <Link to="/services" className="btn-accent">
              استكشاف الخدمات
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
