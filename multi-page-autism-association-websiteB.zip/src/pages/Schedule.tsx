import { useState } from "react";

interface Session {
  id: string;
  day: string;
  time: string;
  title: string;
  therapist: string;
  description: string;
  color: string;
}

interface ModalData {
  isOpen: boolean;
  session: Session | null;
}

export default function Schedule() {
  const [modal, setModal] = useState<ModalData>({ isOpen: false, session: null });

  const weeklySchedule: Session[] = [
    {
      id: "1",
      day: "الأحد",
      time: "09:00 - 10:30",
      title: "جلسة تخاطب",
      therapist: "أخصائية التخاطب",
      description: "برنامج لتطوير مهارات التواصل اللفظي وغير اللفظي للأطفال.",
      color: "bg-primary",
    },
    {
      id: "2",
      day: "الأحد",
      time: "11:00 - 12:30",
      title: "علاج شغلي",
      therapist: "أخصائية العلاج الشغلي",
      description: "أنشطة لتطوير المهارات الحركية الدقيقة والجمالية.",
      color: "bg-secondary",
    },
    {
      id: "3",
      day: "الاثنين",
      time: "09:00 - 10:30",
      title: "تعديل سلوك",
      therapist: "أخصائي تعديل سلوك",
      description: "استراتيجيات لتعديل السلوكيات السلبية وتعزيز الإيجابية.",
      color: "bg-accent",
    },
    {
      id: "4",
      day: "الاثنين",
      time: "14:00 - 15:30",
      title: "دعم نفسي",
      therapist: "أخصائية نفسية",
      description: "جلسات دعم نفسية لأسر الأطفال ذوي التوحد.",
      color: "bg-primary",
    },
    {
      id: "5",
      day: "الثلاثاء",
      time: "10:00 - 11:30",
      title: "تخاطب متقدم",
      therapist: "أخصائية التخاطب",
      description: "برامج متقدمة للأطفال الذين لديهم مهارات تواصل أساسية.",
      color: "bg-secondary",
    },
    {
      id: "6",
      day: "الثلاثاء",
      time: "14:00 - 15:30",
      title: "علاج شغلي",
      therapist: "أخصائية العلاج الشغلي",
      description: "أنشطة عملية لتطوير المهارات الحياتية اليومية.",
      color: "bg-accent",
    },
    {
      id: "7",
      day: "الأربعاء",
      time: "09:00 - 10:30",
      title: "تعديل سلوك",
      therapist: "أخصائي تعديل سلوك",
      description: "جلسات فردية لتعديل السلوكيات التحدية.",
      color: "bg-primary",
    },
    {
      id: "8",
      day: "الأربعاء",
      time: "14:00 - 15:30",
      title: "جلسة جماعية",
      therapist: "فريق العلاج",
      description: "أنشطة جماعية لتطوير المهارات الاجتماعية.",
      color: "bg-secondary",
    },
    {
      id: "9",
      day: "الخميس",
      time: "10:00 - 11:30",
      title: "تخاطب",
      therapist: "أخصائية التخاطب",
      description: "جلسات فردية لتطوير مهارات التواصل.",
      color: "bg-accent",
    },
    {
      id: "10",
      day: "الخميس",
      time: "14:00 - 15:30",
      title: "دعم نفسي",
      therapist: "أخصائية نفسية",
      description: "جلسات دعم لأمهات الأطفال ذوي التوحد.",
      color: "bg-primary",
    },
  ];

  const daysOfWeek = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];

  const openModal = (session: Session) => {
    setModal({ isOpen: true, session });
  };

  const closeModal = () => {
    setModal({ isOpen: false, session: null });
  };

  const getSessionsForDay = (day: string) => {
    return weeklySchedule.filter((session) => session.day === day);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl lg:text-4xl font-bold text-primary mb-4">
            الجدول الأسبوعي
          </h1>
          <p className="text-lg text-gray-600">
            جدول الجلسات والأنشطة الأسبوعية للجمعية
          </p>
        </div>

        {/* Weekly Schedule Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-6 border-b">
            <div className="flex flex-wrap justify-between items-center gap-4">
              <h2 className="text-xl font-bold text-primary">
                الجلسات الأسبوعية
              </h2>
              <p className="text-gray-500">
                يمكن الضغط على أي جلسة لعرض التفاصيل
              </p>
            </div>
          </div>

          <div className="table-container">
            <table className="table">
              <thead className="bg-light">
                <tr>
                  <th className="text-right text-primary font-bold">اليوم</th>
                  <th className="text-right text-primary font-bold">الوقت</th>
                  <th className="text-right text-primary font-bold">الجلسة</th>
                  <th className="text-right text-primary font-bold">الأخصائي</th>
                  <th className="text-right text-primary font-bold">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {daysOfWeek.map((day) => {
                  const daySessions = getSessionsForDay(day);
                  
                  if (daySessions.length === 0) {
                    return (
                      <tr key={day} className="bg-gray-50">
                        <td className="font-medium text-primary">{day}</td>
                        <td colSpan={4} className="text-center text-gray-400">
                          لا يوجد جلسات
                        </td>
                      </tr>
                    );
                  }

                  return daySessions.map((session, index) => (
                    <tr
                      key={session.id}
                      className={`hover:bg-light transition-colors ${
                        index % 2 === 0 ? "bg-white" : "bg-gray-50"
                      }`}
                    >
                      <td className="font-medium text-primary">
                        {index === 0 ? day : ""}
                      </td>
                      <td className="text-gray-600">{session.time}</td>
                      <td className="font-medium text-gray-800">
                        <span
                          className={`inline-block px-3 py-1 rounded-full text-sm font-medium text-white ${session.color}`}
                        >
                          {session.title}
                        </span>
                      </td>
                      <td className="text-gray-600">{session.therapist}</td>
                      <td>
                        <button
                          onClick={() => openModal(session)}
                          className="text-primary hover:text-blue-700 transition-colors"
                        >
                          <i className="fas fa-info-circle text-xl"></i>
                        </button>
                      </td>
                    </tr>
                  ));
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Alternative Card View */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-primary mb-6">
            عرض حسب اليوم
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {daysOfWeek.map((day) => {
              const daySessions = getSessionsForDay(day);
              
              return (
                <div key={day} className="bg-white p-6 rounded-xl shadow-md">
                  <h3 className="text-lg font-bold text-primary mb-4 flex items-center">
                    <i className="fas fa-calendar-day text-primary mr-2"></i>
                    {day}
                  </h3>
                  {daySessions.length > 0 ? (
                    <div className="space-y-4">
                      {daySessions.map((session) => (
                        <div
                          key={session.id}
                          className="p-4 bg-light rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
                          onClick={() => openModal(session)}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <p className="text-sm text-gray-500">{session.time}</p>
                              <h4 className="font-bold text-primary">{session.title}</h4>
                              <p className="text-sm text-gray-600">{session.therapist}</p>
                            </div>
                            <span
                              className={`px-2 py-1 rounded text-xs text-white ${session.color}`}
                            >
                              تفاصيل
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-400 text-center py-4">
                      لا يوجد جلسات
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Notes Section */}
        <div className="mt-12 bg-white p-6 rounded-xl shadow-md">
          <h2 className="text-xl font-bold text-primary mb-4">
            ملاحظات مهمة
          </h2>
          <ul className="space-y-3">
            <li className="flex items-start">
              <i className="fas fa-info-circle text-primary mt-1 mr-3"></i>
              <span>الجلسات تتطلب حجزًا مسبقًا من خلال صفحة التواصل</span>
            </li>
            <li className="flex items-start">
              <i className="fas fa-info-circle text-primary mt-1 mr-3"></i>
              <span>مدة كل جلسة هي 90 دقيقة إلا إذا تم الاتفاق على خلاف ذلك</span>
            </li>
            <li className="flex items-start">
              <i className="fas fa-info-circle text-primary mt-1 mr-3"></i>
              <span>يرجى الوصول قبل 10 دقائق من بداية الجلسة</span>
            </li>
            <li className="flex items-start">
              <i className="fas fa-info-circle text-primary mt-1 mr-3"></i>
              <span>في حالة الغياب، يرجى إبلاغ الجمعية مسبقًا</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Modal for Session Details */}
      {modal.isOpen && modal.session && (
        <div className="modal-overlay" onClick={closeModal}>
          <div
            className="modal-content"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold text-primary">
                تفاصيل الجلسة
              </h2>
              <button
                onClick={closeModal}
                className="text-gray-400 hover:text-gray-600 text-2xl"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>
            <div className="space-y-4">
              <div className={`p-4 rounded-lg text-center ${modal.session.color}`}>
                <h3 className="text-2xl font-bold text-white">
                  {modal.session.title}
                </h3>
                <p className="text-white opacity-90">{modal.session.day} - {modal.session.time}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-gray-500 text-sm">اليوم</p>
                  <p className="font-medium text-primary">{modal.session.day}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-sm">الوقت</p>
                  <p className="font-medium text-primary">{modal.session.time}</p>
                </div>
                <div>
                  <p className="text-gray-500 text-sm">الأخصائي</p>
                  <p className="font-medium text-primary">{modal.session.therapist}</p>
                </div>
              </div>
              <div>
                <p className="text-gray-500 text-sm mb-2">الوصف</p>
                <p className="text-gray-600 bg-light p-4 rounded-lg">
                  {modal.session.description}
                </p>
              </div>
            </div>
            <div className="mt-6 text-center">
              <button onClick={closeModal} className="btn-secondary">
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
