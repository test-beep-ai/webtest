import { useState } from "react";

interface RoutineActivity {
  id: string;
  name: string;
  icon: string;
  color: string;
}

interface RoutineItem {
  id: string;
  activity: RoutineActivity;
  time: string;
  duration: string;
}

export default function RoutineBuilder() {
  const [availableActivities] = useState<RoutineActivity[]>([
    {
      id: "wake-up",
      name: "الاستيقاظ",
      icon: "fa-bed",
      color: "bg-secondary",
    },
    {
      id: "wash",
      name: "الغسيل",
      icon: "fa-shower",
      color: "bg-primary",
    },
    {
      id: "breakfast",
      name: "الإفطار",
      icon: "fa-utensils",
      color: "bg-accent",
    },
    {
      id: "therapy",
      name: "جلسة علاجية",
      icon: "fa-user-md",
      color: "bg-primary",
    },
    {
      id: "play",
      name: "وقت اللعب",
      icon: "fa-gamepad",
      color: "bg-secondary",
    },
    {
      id: "study",
      name: "الدراسة",
      icon: "fa-book",
      color: "bg-accent",
    },
    {
      id: "lunch",
      name: "الغداء",
      icon: "fa-hamburger",
      color: "bg-primary",
    },
    {
      id: "rest",
      name: "الراحة",
      icon: "fa-couch",
      color: "bg-secondary",
    },
    {
      id: "dinner",
      name: "العشاء",
      icon: "fa-pizza-slice",
      color: "bg-accent",
    },
    {
      id: "sleep",
      name: "النوم",
      icon: "fa-moon",
      color: "bg-primary",
    },
  ]);

  const [routine, setRoutine] = useState<RoutineItem[]>([]);
  const [selectedActivity, setSelectedActivity] = useState<RoutineActivity | null>(null);
  const [time, setTime] = useState("");
  const [duration, setDuration] = useState("30");

  const addActivity = () => {
    if (!selectedActivity || !time) return;

    const newItem: RoutineItem = {
      id: `${Date.now()}-${selectedActivity.id}`,
      activity: selectedActivity,
      time,
      duration: `${duration} دقيقة`,
    };

    setRoutine([...routine, newItem]);
    setSelectedActivity(null);
    setTime("");
    setDuration("30");
  };

  const removeActivity = (id: string) => {
    setRoutine(routine.filter((item) => item.id !== id));
  };

  const moveActivity = (index: number, direction: "up" | "down") => {
    if (index < 0 || index >= routine.length) return;

    const newRoutine = [...routine];
    const targetIndex = direction === "up" ? index - 1 : index + 1;

    if (targetIndex < 0 || targetIndex >= routine.length) return;

    // Swap items
    [newRoutine[index], newRoutine[targetIndex]] = [
      newRoutine[targetIndex],
      newRoutine[index],
    ];

    setRoutine(newRoutine);
  };

  const printRoutine = () => {
    window.print();
  };

  const clearRoutine = () => {
    setRoutine([]);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl lg:text-4xl font-bold text-primary mb-4">
            صانع الروتين اليومي
          </h1>
          <p className="text-lg text-gray-600">
            أنشئ جدولاً روتينيًا مخصصًا لطفلك بسهولة
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Available Activities */}
          <div className="lg:col-span-1">
            <div className="bg-white p-6 rounded-xl shadow-md">
              <h2 className="text-xl font-bold text-primary mb-4">
                الأنشطة المتاحة
              </h2>
              <div className="grid grid-cols-2 gap-3 max-h-[500px] overflow-y-auto">
                {availableActivities.map((activity) => (
                  <button
                    key={activity.id}
                    onClick={() => setSelectedActivity(activity)}
                    className={`p-4 rounded-xl text-center transition-all ${
                      selectedActivity?.id === activity.id
                        ? `${activity.color} text-white`
                        : "bg-gray-50 hover:bg-gray-100"
                    }`}
                    title={activity.name}
                  >
                    <i
                      className={`fas ${activity.icon} text-2xl mb-2 block`}
                    ></i>
                    <span className="text-sm font-medium">{activity.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Add Activity Form */}
            <div className="bg-white p-6 rounded-xl shadow-md mt-6">
              <h2 className="text-xl font-bold text-primary mb-4">
                إضافة نشاط
              </h2>
              {selectedActivity && (
                <div className="space-y-4">
                  <div className="bg-light p-3 rounded-lg">
                    <p className="font-medium text-primary">
                      النشاط المختار: {selectedActivity.name}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      الوقت
                    </label>
                    <input
                      type="time"
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      className="input-field"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      المدة (دقائق)
                    </label>
                    <select
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      className="input-field"
                    >
                      <option value="15">15 دقيقة</option>
                      <option value="30">30 دقيقة</option>
                      <option value="45">45 دقيقة</option>
                      <option value="60">60 دقيقة</option>
                      <option value="90">90 دقيقة</option>
                      <option value="120">120 دقيقة</option>
                    </select>
                  </div>
                  <button
                    onClick={addActivity}
                    className="btn-primary w-full"
                    disabled={!time}
                  >
                    إضافة إلى الروتين
                  </button>
                </div>
              )}
              {!selectedActivity && (
                <p className="text-gray-500 text-center py-4">
                  اختر نشاطًا من القائمة
                </p>
              )}
            </div>
          </div>

          {/* Routine Builder */}
          <div className="lg:col-span-2">
            <div className="bg-white p-6 rounded-xl shadow-md print-area">
              <div className="flex justify-between items-center mb-4 no-print">
                <h2 className="text-xl font-bold text-primary">
                  الروتين اليومي
                </h2>
                <div className="flex gap-2">
                  <button
                    onClick={printRoutine}
                    className="btn-secondary text-sm px-4 py-2"
                  >
                    <i className="fas fa-print mr-1"></i>
                    طباعة
                  </button>
                  <button
                    onClick={clearRoutine}
                    className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium"
                    disabled={routine.length === 0}
                  >
                    <i className="fas fa-trash mr-1"></i>
                    مسح الكل
                  </button>
                </div>
              </div>

              {routine.length === 0 ? (
                <div className="text-center py-12">
                  <i className="fas fa-calendar-plus text-primary text-6xl mb-4"></i>
                  <p className="text-gray-500">
                    لم يتم إضافة أي أنشطة بعد
                  </p>
                  <p className="text-gray-400 text-sm mt-2">
                    اختر نشاطًا من القائمة وأضفه إلى الروتين
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {routine.map((item, index) => (
                    <div
                      key={item.id}
                      className="routine-card border-l-4 border-primary"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div
                            className={`w-12 h-12 rounded-full flex items-center justify-center ${item.activity.color}`}
                          >
                            <i
                              className={`fas ${item.activity.icon} text-white`}
                            ></i>
                          </div>
                          <div>
                            <h3 className="font-bold text-primary">
                              {item.activity.name}
                            </h3>
                            <div className="flex items-center space-x-4 text-sm text-gray-600">
                              <span>
                                <i className="fas fa-clock mr-1"></i>
                                {item.time}
                              </span>
                              <span>
                                <i className="fas fa-hourglass-half mr-1"></i>
                                {item.duration}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2 no-print">
                          <button
                            onClick={() => moveActivity(index, "up")}
                            disabled={index === 0}
                            className="p-2 text-primary hover:bg-light rounded-lg disabled:opacity-30"
                          >
                            <i className="fas fa-arrow-up"></i>
                          </button>
                          <button
                            onClick={() => moveActivity(index, "down")}
                            disabled={index === routine.length - 1}
                            className="p-2 text-primary hover:bg-light rounded-lg disabled:opacity-30"
                          >
                            <i className="fas fa-arrow-down"></i>
                          </button>
                          <button
                            onClick={() => removeActivity(item.id)}
                            className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                          >
                            <i className="fas fa-times"></i>
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Print Only Header */}
            <div className="print-only text-center py-4 mt-4">
              <h2 className="text-2xl font-bold text-primary">
                جدول الروتين اليومي
              </h2>
              <p className="text-gray-600">
                جمعية الأمل لأطفال طيف التوحد
              </p>
            </div>
          </div>
        </div>

        {/* Tips Section */}
        <div className="mt-12 bg-white p-6 rounded-xl shadow-md">
          <h2 className="text-xl font-bold text-primary mb-4">
            نصائح لإنشاء روتين فعال
          </h2>
          <ul className="space-y-3">
            <li className="flex items-start">
              <i className="fas fa-check-circle text-primary mt-1 mr-3"></i>
              <span>ابدأ بأنشطة بسيطة وسهلة التحقق</span>
            </li>
            <li className="flex items-start">
              <i className="fas fa-check-circle text-primary mt-1 mr-3"></i>
              <span>حافظ على أوقات ثابتة لأنشطة الروتين اليومية</span>
            </li>
            <li className="flex items-start">
              <i className="fas fa-check-circle text-primary mt-1 mr-3"></i>
              <span>استخدم الصور والأيقونات لمساعدة الطفل على الفهم</span>
            </li>
            <li className="flex items-start">
              <i className="fas fa-check-circle text-primary mt-1 mr-3"></i>
              <span>كن مرنًا وقابلًا للتعديل حسب احتياجات الطفل</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
