import { Link } from "react-router-dom";

interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  benefits: string[];
}

export default function Services() {
  const services: Service[] = [
    {
      id: "speech-therapy",
      title: "التخاطب",
      description: 
        "برامج علاج التخاطب متخصصة لأطفال طيف التوحد، تهدف إلى تطوير مهارات التواصل اللفظي وغير اللفظي. نستخدم أساليب حديثة ومبتكرة لمساعدة الطفل على التعبير عن نفسه وفهم الآخرين.",
      icon: "fa-microphone",
      color: "bg-primary",
      benefits: [
        "تطوير مهارات الكلام والنطق",
        "تعزيز فهم اللغة والتواصل",
        "تحسين التفاعل الاجتماعي",
        "تعلم استخدام وسائل التواصل البديلة (AAC)",
      ],
    },
    {
      id: "orthophony",
      title: "أخصائي أرثوفوني",
      description: 
        "العلاج الأرثوفوني هو تخصص طبي يعنى بتقييم وعلاج اضطرابات الكلام واللغة والتواصل. نقدم جلسات فردية ومتخصصة لكل طفل حسب احتياجاته.",
      icon: "fa-stethoscope",
      color: "bg-secondary",
      benefits: [
        "تشخيص اضطرابات الكلام واللغة",
        "علاج مشاكل النطق والتلعثم",
        "تطوير مهارات الاستماع والفهم",
        "تحسين جودة الصوت والطلاقة",
      ],
    },
    {
      id: "behavior-modification",
      title: "تعديل السلوك",
      description: 
        "برنامج تعديل السلوك يهدف إلى مساعدة الأطفال على التعلم والتكيف مع بيئتهم من خلال تعزيز السلوكيات الإيجابية وتقليل السلوكيات السلبية أو التحدية.",
      icon: "fa-brain",
      color: "bg-accent",
      benefits: [
        "تقليل السلوكيات التحدية (العدوان، الصراخ، إلخ)",
        "تعزيز السلوكيات الإيجابية",
        "تطوير مهارات التعلم والاستجابة",
        "تحسين القدرة على التركيز والانتباه",
      ],
    },
    {
      id: "occupational-therapy",
      title: "العلاج الشغلي",
      description: 
        "العلاج الشغلي يساعد الأطفال على تطوير المهارات الحركية الدقيقة والجمالية اللازمة لأداء الأنشطة اليومية. نركز على تحسين الاستقلال الذاتي والجودة الحياتية.",
      icon: "fa-hands",
      color: "bg-primary",
      benefits: [
        "تطوير المهارات الحركية الدقيقة (الكتابة، الرسم، إلخ)",
        "تحسين المهارات الحركية الجمالية (المشي، الجري، إلخ)",
        "تعلم أنشطة الحياة اليومية (اللبس، الأكل، الاستحمام)",
        "تحسين التنسيق بين العين واليد",
      ],
    },
    {
      id: "psychological-support",
      title: "الدعم النفسي",
      description: 
        "نقدم جلسات دعم نفسية لأسر الأطفال ذوي التوحد. هدفنا هو توفير بيئة آمنة وداعمة للأهل لتبادل الخبرات وتعلم استراتيجيات التعامل مع التحديات.",
      icon: "fa-heart",
      color: "bg-secondary",
      benefits: [
        "دعم نفسي لأمهات وأباء الأطفال ذوي التوحد",
        "تعلم استراتيجيات التعامل مع الضغوط",
        "تبادل الخبرات مع آباء آخرين",
        "الحصول على إرشادات تربوية متخصصة",
      ],
    },
    {
      id: "sensory-integration",
      title: "تكامل حسي",
      description: 
        "برنامج تكامل حسي مصمم لمساعدة الأطفال على معالجة المعلومات الحسية بشكل أفضل. هذا يساعد في تقليل الحساسية المفرطة أو نقص الحساسية للمؤثرات الحسية.",
      icon: "fa-eye",
      color: "bg-accent",
      benefits: [
        "تحسين معالجة المعلومات الحسية",
        "تقليل الحساسية للمؤثرات الحسية (ضوء، صوت، لمس)",
        "تحسين القدرة على التركيز",
        "تقليل سلوكيات التحفيز الذاتي",
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl lg:text-4xl font-bold text-primary mb-4">
            خدماتنا وبرامجنا العلاجية
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            نقدم مجموعة شاملة من الخدمات العلاجية والتأهيلية لأطفال طيف التوحد
            وأسرهم
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {services.map((service) => (
            <div
              key={service.id}
              className="service-card bg-white"
            >
              <div className="flex items-start space-x-4">
                <div
                  className={`w-16 h-16 rounded-xl flex items-center justify-center flex-shrink-0 ${service.color}`}
                >
                  <i className={`fas ${service.icon} text-white text-2xl`}></i>
                </div>
                <div className="flex-1">
                  <h2 className="text-xl font-bold text-primary mb-2">
                    {service.title}
                  </h2>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <Link
                    to="/contact"
                    className="inline-flex items-center text-primary font-medium hover:underline"
                  >
                    <i className="fas fa-calendar-alt mr-2"></i>
                    حجز موعد
                  </Link>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-gray-100">
                <h3 className="text-sm font-bold text-primary mb-3">
                  فوائد الخدمة:
                </h3>
                <ul className="space-y-2">
                  {service.benefits.map((benefit, index) => (
                    <li key={index} className="flex items-center text-sm text-gray-600">
                      <i className="fas fa-check-circle text-primary mr-2 text-xs"></i>
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        {/* Pricing and Packages */}
        <section className="bg-white p-8 rounded-xl shadow-md mb-12">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-primary mb-4">
              الباقات العلاجية
            </h2>
            <p className="text-gray-600">
              نقدم باقات علاجية مرنة تناسب احتياجات كل طفل
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-light p-6 rounded-xl text-center">
              <h3 className="text-xl font-bold text-primary mb-2">باقة أساسية</h3>
              <p className="text-3xl font-bold text-secondary mb-4">2 جلسات/أسبوع</p>
              <ul className="space-y-2 text-gray-600 mb-6">
                <li>جلستان فرديتان أسبوعيًا</li>
                <li>تقييم أولي شامل</li>
                <li>متابعة دورية</li>
                <li>دعم عبر الهاتف</li>
              </ul>
              <Link to="/contact" className="btn-primary">
                حجز الآن
              </Link>
            </div>

            <div className="bg-light p-6 rounded-xl text-center border-2 border-primary">
              <h3 className="text-xl font-bold text-primary mb-2">باقة متقدمة</h3>
              <p className="text-3xl font-bold text-primary mb-4">4 جلسات/أسبوع</p>
              <ul className="space-y-2 text-gray-600 mb-6">
                <li>أربع جلسات فردية أسبوعيًا</li>
                <li>تقييم أولي شامل</li>
                <li>متابعة دورية متقدمة</li>
                <li>دعم عبر الهاتف والإيميل</li>
                <li>جلسة جماعية أسبوعية</li>
              </ul>
              <Link to="/contact" className="btn-primary">
                حجز الآن
              </Link>
            </div>

            <div className="bg-light p-6 rounded-xl text-center">
              <h3 className="text-xl font-bold text-primary mb-2">باقة شاملة</h3>
              <p className="text-3xl font-bold text-accent mb-4">6 جلسات/أسبوع</p>
              <ul className="space-y-2 text-gray-600 mb-6">
                <li>ست جلسات فردية أسبوعيًا</li>
                <li>تقييم أولي شامل</li>
                <li>متابعة دورية شاملة</li>
                <li>دعم كامل عبر الهاتف والإيميل</li>
                <li>جلستان جماعيتان أسبوعيًا</li>
                <li>برنامج منزل مخصص</li>
              </ul>
              <Link to="/contact" className="btn-primary">
                حجز الآن
              </Link>
            </div>
          </div>
        </section>

        {/* How We Work */}
        <section className="bg-white p-8 rounded-xl shadow-md">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-primary mb-4">
              كيف نعمل؟
            </h2>
            <p className="text-gray-600">
              عملية العلاج لدينا تتبع منهجية علمية ومتخصصة
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-file-alt text-primary text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-primary mb-2">التسجيل</h3>
              <p className="text-gray-600 text-sm">
                ملء استمارة التسجيل عبر الإنترنت أو زيارة مقر الجمعية
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-secondary bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-user-check text-secondary text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-primary mb-2">التقييم</h3>
              <p className="text-gray-600 text-sm">
                جلسة تقييم أولي لتحديد احتياجات الطفل وأهداف العلاج
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-accent bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-calendar-alt text-accent text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-primary mb-2">تحديد المواعيد</h3>
              <p className="text-gray-600 text-sm">
                تحديد مواعيد الجلسات بناءً على جدول الطفل والأخصائي
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-primary bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-rocket text-primary text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-primary mb-2">بدء العلاج</h3>
              <p className="text-gray-600 text-sm">
                بداية جلسات العلاج والمتابعة الدورية لتقييم التقدم
              </p>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <div className="text-center mt-12">
          <h2 className="text-2xl font-bold text-primary mb-4">
            جاهز لبدء الرحلة؟
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            حدد موعدًا اليوم لبدء برنامج العلاج لطفلك
          </p>
          <Link to="/contact" className="btn-primary text-lg px-8 py-4">
            حجز موعد الآن
          </Link>
        </div>
      </div>
    </div>
  );
}
