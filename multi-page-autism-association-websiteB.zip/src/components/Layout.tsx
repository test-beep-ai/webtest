import { Outlet } from "react-router-dom";
import Navbar from "./Navbar";
import Footer from "./Footer";
import AccessibilityToolbar from "./AccessibilityToolbar";

export default function Layout() {
  return (
    <div className="min-h-screen flex flex-col" dir="rtl">
      <AccessibilityToolbar />
      <Navbar />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}
