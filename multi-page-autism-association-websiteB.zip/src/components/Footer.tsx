export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Association Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center">
                <i className="fas fa-heart text-gray-800 text-xl"></i>
              </div>
              <div>
                <h3 className="text-xl font-bold">جمعية الأمل</h3>
                <p className="text-gray-300">لأطفال طيف التوحد</p>
              </div>
            </div>
            <div className="space-y-2 text-gray-300">
              <p className="flex items-center">
                <i className="fas fa-map-marker-alt text-accent mr-2"></i>
                حي العربي بن مهيدي، ص.ب 84، الحناية، تلمسان، الجزائر
              </p>
              <p className="flex items-center">
                <i className="fas fa-envelope text-accent mr-2"></i>
                autisme.hennaya@hotmail.com
              </p>
              <p className="flex items-center">
                <i className="fas fa-phone text-accent mr-2"></i>
                بلدية الحناية
              </p>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-4">روابط سريعة</h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="/"
                  className="text-gray-300 hover:text-accent transition-colors"
                >
                  الرئيسية
                </a>
              </li>
              <li>
                <a
                  href="/routine"
                  className="text-gray-300 hover:text-accent transition-colors"
                >
                  صانع الروتين
                </a>
              </li>
              <li>
                <a
                  href="/schedule"
                  className="text-gray-300 hover:text-accent transition-colors"
                >
                  الجدول الأسبوعي
                </a>
              </li>
              <li>
                <a
                  href="/services"
                  className="text-gray-300 hover:text-accent transition-colors"
                >
                  الخدمات
                </a>
              </li>
              <li>
                <a
                  href="/contact"
                  className="text-gray-300 hover:text-accent transition-colors"
                >
                  التواصل
                </a>
              </li>
            </ul>
          </div>

          {/* Social Media and Facebook */}
          <div>
            <h3 className="text-xl font-bold mb-4">تابعونا على</h3>
            <div className="space-y-4">
              <a
                href="https://www.facebook.com/profile.php?id=61590665260682"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center w-full bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg transition-colors"
              >
                <i className="fab fa-facebook text-2xl mr-3"></i>
                <span>صفحتنا على الفيسبوك</span>
              </a>
              <p className="text-center text-gray-400 text-sm">
                تفضل بزيارتنا على صفحة الفيسبوك الرسمية
              </p>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
          <p>© 2026 جمعية الأمل لأطفال طيف التوحد (بلدية الحنايا). جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  );
}
