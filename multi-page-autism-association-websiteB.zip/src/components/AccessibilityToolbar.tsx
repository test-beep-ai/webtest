import { useState, useEffect } from "react";

export default function AccessibilityToolbar() {
  const [highContrast, setHighContrast] = useState(false);
  const [fontSize, setFontSize] = useState(100);

  useEffect(() => {
    if (highContrast) {
      document.body.classList.add("high-contrast");
    } else {
      document.body.classList.remove("high-contrast");
    }
  }, [highContrast]);

  useEffect(() => {
    document.body.style.fontSize = `${fontSize}%`;
  }, [fontSize]);

  const toggleHighContrast = () => {
    setHighContrast(!highContrast);
  };

  const increaseFontSize = () => {
    setFontSize(Math.min(fontSize + 10, 200));
  };

  const decreaseFontSize = () => {
    setFontSize(Math.max(fontSize - 10, 80));
  };

  const resetSettings = () => {
    setHighContrast(false);
    setFontSize(100);
  };

  return (
    <div className="accessibility-toolbar no-print">
      <button
        onClick={toggleHighContrast}
        className="accessibility-btn"
        title={highContrast ? "إلغاء وضع التباين العالي" : "تفعيل وضع التباين العالي"}
        aria-label={highContrast ? "إلغاء وضع التباين العالي" : "تفعيل وضع التباين العالي"}
      >
        <i className={`fas ${highContrast ? "fa-sun" : "fa-moon"}`}></i>
      </button>
      
      <button
        onClick={increaseFontSize}
        className="accessibility-btn"
        title="تكبير الخط"
        aria-label="تكبير الخط"
      >
        <i className="fas fa-text-plus"></i>
      </button>
      
      <button
        onClick={decreaseFontSize}
        className="accessibility-btn"
        title="تصغير الخط"
        aria-label="تصغير الخط"
      >
        <i className="fas fa-text-minus"></i>
      </button>
      
      <button
        onClick={resetSettings}
        className="accessibility-btn"
        title="إعادة الضبط"
        aria-label="إعادة الضبط"
      >
        <i className="fas fa-redo"></i>
      </button>
    </div>
  );
}
