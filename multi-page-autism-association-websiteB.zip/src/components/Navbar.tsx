import { Link, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";

export default function Navbar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <nav className="bg-primary shadow-lg no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo and Association Name */}
          <div className="flex-shrink-0 flex items-center">
            <Link to="/" className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                <i className="fas fa-heart text-primary text-xl"></i>
              </div>
              <div>
                <h1 className="text-white font-bold text-lg">جمعية الأمل</h1>
                <p className="text-white text-sm opacity-90">لأطفال طيف التوحد</p>
              </div>
            </Link>
          </div>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center space-x-1">
            <Link
              to="/"
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive("/")
                  ? "bg-white text-primary"
                  : "text-white hover:bg-white hover:bg-opacity-20"
              }`}
            >
              الرئيسية
            </Link>
            <Link
              to="/routine"
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive("/routine")
                  ? "bg-white text-primary"
                  : "text-white hover:bg-white hover:bg-opacity-20"
              }`}
            >
              صانع الروتين
            </Link>
            <Link
              to="/schedule"
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive("/schedule")
                  ? "bg-white text-primary"
                  : "text-white hover:bg-white hover:bg-opacity-20"
              }`}
            >
              الجدول الأسبوعي
            </Link>
            <Link
              to="/services"
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive("/services")
                  ? "bg-white text-primary"
                  : "text-white hover:bg-white hover:bg-opacity-20"
              }`}
            >
              الخدمات
            </Link>
            <Link
              to="/contact"
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive("/contact")
                  ? "bg-white text-primary"
                  : "text-white hover:bg-white hover:bg-opacity-20"
              }`}
            >
              التواصل
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-white p-2 rounded-lg bg-white bg-opacity-20 hover:bg-opacity-30"
              aria-label="فتح القائمة"
            >
              <i className="fas fa-bars text-xl"></i>
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        <div
          className={`md:hidden bg-primary bg-opacity-95 pb-4 ${isMobileMenuOpen ? "block" : "hidden"}`}
        >
          <div className="px-4 pt-2 pb-3 space-y-1">
            <Link
              to="/"
              className={`block px-3 py-2 rounded-lg text-base font-medium ${
                isActive("/")
                  ? "bg-white text-primary"
                  : "text-white hover:bg-white hover:bg-opacity-20"
              }`}
            >
              الرئيسية
            </Link>
            <Link
              to="/routine"
              className={`block px-3 py-2 rounded-lg text-base font-medium ${
                isActive("/routine")
                  ? "bg-white text-primary"
                  : "text-white hover:bg-white hover:bg-opacity-20"
              }`}
            >
              صانع الروتين
            </Link>
            <Link
              to="/schedule"
              className={`block px-3 py-2 rounded-lg text-base font-medium ${
                isActive("/schedule")
                  ? "bg-white text-primary"
                  : "text-white hover:bg-white hover:bg-opacity-20"
              }`}
            >
              الجدول الأسبوعي
            </Link>
            <Link
              to="/services"
              className={`block px-3 py-2 rounded-lg text-base font-medium ${
                isActive("/services")
                  ? "bg-white text-primary"
                  : "text-white hover:bg-white hover:bg-opacity-20"
              }`}
            >
              الخدمات
            </Link>
            <Link
              to="/contact"
              className={`block px-3 py-2 rounded-lg text-base font-medium ${
                isActive("/contact")
                  ? "bg-white text-primary"
                  : "text-white hover:bg-white hover:bg-opacity-20"
              }`}
            >
              التواصل
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
